export const series = [
  {argumentField: 'Flow5A', valueField: 'Powr5A', name: 'ПЭН-5A', type: 'line'},
  {argumentField: 'Flow5B', valueField: 'Powr5B', name: 'ПЭН-5Б', type: 'line'},
  {argumentField: 'Flow6A', valueField: 'Powr6A', name: 'ПЭН-6A', type: 'line'},
  {argumentField: 'Flow6B', valueField: 'Powr6B', name: 'ПЭН-6Б', type: 'line'},
  {argumentField: 'Flow7A', valueField: 'Powr7A', name: 'ПЭН-7A', type: 'line'},
  {argumentField: 'Flow7B', valueField: 'Powr7B', name: 'ПЭН-7Б', type: 'line'},
  {argumentField: 'Flow8A', valueField: 'Powr8A', name: 'ПЭН-8A', type: 'line'},
  {argumentField: 'Flow8B', valueField: 'Powr8B', name: 'ПЭН-8Б', type: 'line'},
  {argumentField: 'Flow9A', valueField: 'Powr9A', name: 'ПЭН-9A', type: 'line'},
  {argumentField: 'Flow9B', valueField: 'Powr9B', name: 'ПЭН-9Б', type: 'line'},
]

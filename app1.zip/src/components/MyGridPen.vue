<template>
  <DxDataGrid> </DxDataGrid>
</template>

<script>
import DxDataGrid from 'devextreme-vue/data-grid'
export default {
  name: 'MyGridPen',
  components: {
    DxDataGrid,
  },
}
</script>

<style></style>
